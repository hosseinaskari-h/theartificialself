===============================================================================
  TERRAFLUX (Apple macOS Beta Independent Release)
  Topographic Logistics & Physical Survival Strategy Game
===============================================================================

A game by Hossein Askari
Contact: hossein@theartificialself.com

COMPATIBILITY:
  - Universal 2 Binary: Runs natively on Apple Silicon (M1, M2, M3, M4)
    and Intel Core Macs (x86_64).
  - Requires macOS 11.0 (Big Sur) or newer.

LAUNCH INSTRUCTIONS:
  1. Drag "TERRAFLUX.app" to your /Applications folder or run it from anywhere.
  2. Double-click TERRAFLUX.app to launch (starts in borderless fullscreen).
     (If macOS Gatekeeper shows an unnotarized app prompt:
      Right-click -> Open, then click "Open", or go to
      System Settings -> Privacy & Security and click "Open Anyway").

CONTROLS:
  - Pan Camera: Arrow Keys or Left-Click Drag on map canvas
  - Zoom Camera: Mouse Scroll Wheel / Trackpad Pinch
  - Pause / Resume: Spacebar
  - Screenshots:
      * F10 / F2 : Clean Map Only (pristine background terrain without UI/nodes)
      * F12      : Full Screen with HUD and live telemetry
  - Compendium: Main Menu or In-Game HUD button to view 24 Units & 1,684 Roles
  - Fullscreen: F11 toggle
  - Time Acceleration: 0.5x, 1x, 4x, 24x speed multipliers in HUD
  - Audio Volume: Adjustable in Main Menu -> Settings
===============================================================================
