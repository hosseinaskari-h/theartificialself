========================================================================
                       T E R R A F L U X
       Topographic Logistics & Physical Survival Strategy Game
                     [BETA INDEPENDENT RELEASE]
========================================================================

A game by Hossein Askari
Contact: hossein@theartificialself.com

QUICK START:
  1. Double-click "TERRAFLUX.exe" to launch (starts in borderless fullscreen).
  2. Select [NEW GAME] from the Main Menu:
     - Choose "Campaign" for the Landfall Wagon survival experience
       with the 7-tier Commission Progression ("The Ledger of Necessity").
     - Choose "Sandbox" for the full 24-unit, 1,684-role master terminal.
  3. Consult the in-game [COMPENDIUM & LEXICON] from the Main Menu or HUD
     for wiring guides, unit schematics, and role-by-role specifications.

KEYBOARD & MOUSE CONTROLS:
  W, A, S, D / Arrows  : Pan topographic survey camera
  Mouse Scroll-Wheel   : Zoom survey elevation scale (4x to 76x)
  Middle-Click Drag    : High-speed cartographic panning
  Spacebar             : Pause / Resume simulation clock
  E                    : Toggle Wire / Pipeline Drafting tool
  T                    : Open 7-Tier Tech Tree window
  F5                   : Quick-Save current expedition
  F9                   : Quick-Load last saved expedition
  F10 / F2             : Capture pristine Clean Map screenshot (no UI/nodes)
  F11                  : Toggle Borderless Fullscreen / Windowed mode
  F12                  : Capture Full Screen with HUD & active telemetry
  Escape               : Close open popups or return to Main Menu
========================================================================
