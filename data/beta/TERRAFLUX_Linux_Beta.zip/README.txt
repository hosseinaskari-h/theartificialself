========================================================================
                       T E R R A F L U X
       Topographic Logistics & Physical Survival Strategy Game
                 [LINUX BETA INDEPENDENT RELEASE]
========================================================================

A game by Hossein Askari
Contact: hossein@theartificialself.com

COMPATIBILITY:
  - Architecture: x86_64 GNU/Linux (Ubuntu 20.04+, Debian 11+, Arch, Fedora, openSUSE)
  - Display: X11 and Wayland (via GLFW3 + OpenGL 3.3 Core)
  - Audio: ALSA / PulseAudio / JACK (via miniaudio)

LAUNCH INSTRUCTIONS:
  1. Extract this archive anywhere.
  2. Ensure the binary is executable:
       chmod +x TERRAFLUX
  3. Run directly from terminal or double-click in your desktop environment:
       ./TERRAFLUX
     (The game launches in borderless fullscreen by default).

KEYBOARD & MOUSE CONTROLS:
  W, A, S, D / Arrows  : Pan topographic survey camera
  Mouse Scroll-Wheel   : Zoom survey elevation scale (4x to 76x)
  Middle-Click Drag    : High-speed cartographic panning
  Spacebar             : Pause / Resume simulation clock
  E                    : Toggle Wire / Pipeline Drafting tool
  T                    : Open 7-Tier Tech Tree window
  F5                   : Quick-Save current expedition
  F9                   : Quick-Load last saved expedition
  F10 / F2             : Capture pristine Clean Map screenshot (no UI/nodes)
  F11                  : Toggle Borderless Fullscreen / Windowed mode
  F12                  : Capture Full Screen with HUD & active telemetry
  Escape               : Close open popups or return to Main Menu
========================================================================
